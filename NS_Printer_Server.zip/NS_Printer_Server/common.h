// common.h
#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/hmac.h>

#define AES_KEY_SIZE 32   // 256-bit AES key
#define AES_IV_SIZE 12    // 96-bit IV for AES-GCM
#define AES_TAG_SIZE 16   // 128-bit tag
#define HMAC_SIZE 32      // 256-bit HMAC-SHA256
#define PORT 8080

// Logging function
void log_message(const char *format, ...);

int accept_connection(int server_socket);

// File transfer with encryption
void send_file(int socket, const char *filename, unsigned char *session_key);
void receive_file(int socket, const char *output_filename, unsigned char *session_key);

// Network utilities
int create_server_socket(int port);
int create_client_socket(const char *ip, int port);

// AES-GCM Encryption/Decryption
int aes_gcm_encrypt(unsigned char *plaintext, int plaintext_len,
                    unsigned char *key, unsigned char *iv,
                    unsigned char *ciphertext, unsigned char *tag);

int aes_gcm_decrypt(unsigned char *ciphertext, int ciphertext_len,
                    unsigned char *tag, unsigned char *key, 
                    unsigned char *iv, unsigned char *plaintext);

// Generate a random AES key
void generate_random_key(unsigned char *key, int size);

// HMAC-based authentication
void compute_hmac(unsigned char *key, unsigned char *data, int data_len, unsigned char *hmac);
int verify_hmac(unsigned char *key, unsigned char *data, int data_len, unsigned char *received_hmac);

#endif // COMMON_H