#include "common.h"

#define PORT 8080
unsigned char prnsrv_secret[AES_KEY_SIZE];

void *handle_client(void *arg) {
    int client_sock = *(int *)arg;
    free(arg);

    unsigned char ticket[256];
    if (recv(client_sock, ticket, 256, 0) <= 0) {
        log_message("Error receiving ticket from client.");
        close(client_sock);
        return NULL;
    }
    log_message("Received ticket from client.");

    // Decrypt and verify the session key
    unsigned char session_key[AES_KEY_SIZE];
    unsigned char ticket_tag[AES_TAG_SIZE];
    unsigned char ticket_iv[AES_IV_SIZE]; // IV for AES-GCM decryption

    if (recv(client_sock, ticket_tag, AES_TAG_SIZE, 0) <= 0) {
        log_message("Error receiving ticket tag.");
        close(client_sock);
        return NULL;
    }

    if (aes_gcm_decrypt(ticket, 256, ticket_iv, prnsrv_secret, session_key, ticket_tag) < 0) {
        log_message("Ticket verification failed.");
        close(client_sock);
        return NULL;
    }
    log_message("Session key verified.");

    // Perform challenge-response authentication
    unsigned char challenge[AES_IV_SIZE];
    generate_random_key(challenge, AES_IV_SIZE);
    if (send(client_sock, challenge, AES_IV_SIZE, 0) <= 0) {
        log_message("Error sending challenge to client.");
        close(client_sock);
        return NULL;
    }
    log_message("Sent challenge to client.");

    unsigned char encrypted_challenge[AES_IV_SIZE];
    unsigned char tag[AES_TAG_SIZE];
    if (recv(client_sock, encrypted_challenge, AES_IV_SIZE, 0) <= 0 ||
        recv(client_sock, tag, AES_TAG_SIZE, 0) <= 0) {
        log_message("Error receiving encrypted challenge response.");
        close(client_sock);
        return NULL;
    }

    unsigned char decrypted_challenge[AES_IV_SIZE];
    if (aes_gcm_decrypt(encrypted_challenge, AES_IV_SIZE, challenge, session_key, decrypted_challenge, tag) < 0 ||
        memcmp(challenge, decrypted_challenge, AES_IV_SIZE) != 0) {
        log_message("Challenge verification failed.");
        close(client_sock);
        return NULL;
    }
    log_message("Client authenticated.");

    // Receive file from client
    char input_file[] = "input_received";
    if (receive_file(client_sock, input_file, session_key) < 0) {
        log_message("Error receiving file for conversion.");
        close(client_sock);
        return NULL;
    }
    log_message("Received file for conversion.");

    // Convert file to PDF securely
    char output_file[] = "output.pdf";
    if (fork() == 0) {
        execlp("img2pdf", "img2pdf", input_file, "-o", output_file, NULL);
        exit(1); // Exit if execlp fails
    }
    wait(NULL); // Wait for conversion to finish
    log_message("Converted file to PDF.");

    // Send back the encrypted PDF
    if (send_file(client_sock, output_file, session_key) < 0) {
        log_message("Error sending converted PDF to client.");
        close(client_sock);
        return NULL;
    }
    log_message("Sent converted PDF to client.");

    close(client_sock);
    return NULL;
}

int main() {
    int server_sock = create_server_socket(PORT);
    if (server_sock < 0) {
        log_message("Failed to create server socket.");
        return 1;
    }
    log_message("Print Server is running...");

    generate_random_key(prnsrv_secret, AES_KEY_SIZE);

    while (1) {
        int *client_sock = malloc(sizeof(int));
        if (!client_sock) {
            log_message("Memory allocation failed.");
            continue;
        }

        *client_sock = accept_connection(server_sock);
        if (*client_sock < 0) {
            free(client_sock);
            log_message("Failed to accept client connection.");
            continue;
        }

        pthread_t thread;
        if (pthread_create(&thread, NULL, handle_client, client_sock) != 0) {
            log_message("Failed to create thread for client.");
            free(client_sock);
            continue;
        }
        pthread_detach(thread);
    }

    close(server_sock);
    return 0;
}