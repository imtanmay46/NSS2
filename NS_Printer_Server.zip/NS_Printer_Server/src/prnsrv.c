/* prnsrv.c - Secure Print Server Implementation */
#include "../include/prnsrv.h"
#include "../include/common.h"
#include "../include/crypto.h"
#include "../include/kdc.h"

unsigned char session_key[KEY_SIZE];

int authenticate_client(int sock) {
    Message msg;
    if (recv_message(sock, &msg) != SUCCESS || msg.type != AUTHENTICATE) {
        fprintf(stderr, "Authentication failed\n");
        return FAILURE;
    }
    memcpy(session_key, msg.data, KEY_SIZE);
    return SUCCESS;
}

void handle_client(int client_sock) {
    if (authenticate_client(client_sock) != SUCCESS) {
        close(client_sock);
        return;
    }
    
    printf("Client authenticated successfully. Waiting for print job...\n");
    
    Message msg;
    if (recv_message(client_sock, &msg) != SUCCESS || msg.type != PRINT_JOB) {
        fprintf(stderr, "Invalid print job received\n");
        close(client_sock);
        return;
    }
    
    unsigned char decrypted_data[BUFFER_SIZE];
    int decrypted_len = decrypt_gcm(msg.data, msg.length, session_key, decrypted_data);
    decrypted_data[decrypted_len] = '\0';
    
    printf("Received print job: %s\n", decrypted_data);
    
    close(client_sock);
}

int main() {
    int server_sock = setup_server(PRN_PORT);
    if (server_sock < 0) {
        fprintf(stderr, "Failed to start print server\n");
        return 1;
    }
    
    printf("Print server running on port %d\n", PRN_PORT);
    
    while (1) {
        int client_sock = accept_client(server_sock);
        if (client_sock >= 0) {
            handle_client(client_sock);
        }
    }
    
    close(server_sock);
    return 0;
}