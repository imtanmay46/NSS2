#include "../include/common.h"

int create_socket(int port) {
    int server_fd;
    struct sockaddr_in address;
    
    // Create socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        return ERROR_SOCKET;
    }
    
    // Set socket options to reuse address
    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("Setsockopt failed");
        close(server_fd);
        return ERROR_SOCKET;
    }
    
    // Set up server address structure
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);
    
    // Bind the socket to the specified port
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        return ERROR_BIND;
    }
    
    // Listen for incoming connections
    if (listen(server_fd, MAX_CLIENTS) < 0) {
        perror("Listen failed");
        close(server_fd);
        return ERROR_LISTEN;
    }
    
    return server_fd;
}

int connect_to_server(const char *server_ip, int port) {
    int sock;
    struct sockaddr_in serv_addr;
    
    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        return ERROR_SOCKET;
    }
    
    // Set up server address structure
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    
    // Convert IP address from text to binary form
    if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) {
        perror("Invalid address or address not supported");
        close(sock);
        return ERROR_CONNECT;
    }
    
    // Connect to server
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        close(sock);
        return ERROR_CONNECT;
    }
    
    return sock;
}

int send_message(int socket, Message *msg) {
    // Send message type
    if (send(socket, &msg->type, sizeof(msg->type), 0) != sizeof(msg->type)) {
        perror("Send type failed");
        return ERROR_SOCKET;
    }
    
    // Send message length
    if (send(socket, &msg->length, sizeof(msg->length), 0) != sizeof(msg->length)) {
        perror("Send length failed");
        return ERROR_SOCKET;
    }
    
    // Send message data if length > 0
    if (msg->length > 0) {
        if (send(socket, msg->data, msg->length, 0) != msg->length) {
            perror("Send data failed");
            return ERROR_SOCKET;
        }
    }
    
    return SUCCESS;
}

int receive_message(int socket, Message *msg) {
    // Receive message type
    if (recv(socket, &msg->type, sizeof(msg->type), 0) != sizeof(msg->type)) {
        perror("Receive type failed");
        return ERROR_SOCKET;
    }
    
    // Receive message length
    if (recv(socket, &msg->length, sizeof(msg->length), 0) != sizeof(msg->length)) {
        perror("Receive length failed");
        return ERROR_SOCKET;
    }
    
    // Check if message length is valid
    if (msg->length > BUFFER_SIZE) {
        fprintf(stderr, "Message too large: %zu\n", msg->length);
        return ERROR_SOCKET;
    }
    
    // Receive message data if length > 0
    if (msg->length > 0) {
        size_t bytes_received = 0;
        while (bytes_received < msg->length) {
            int result = recv(socket, msg->data + bytes_received, msg->length - bytes_received, 0);
            if (result <= 0) {
                perror("Receive data failed");
                return ERROR_SOCKET;
            }
            bytes_received += result;
        }
    }
    
    return SUCCESS;
}