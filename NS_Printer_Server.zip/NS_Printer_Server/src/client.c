#include "../include/client.h"
#include "../include/common.h"
#include "../include/crypto.h"
#include "../include/kdc.h"

unsigned char session_key[KEY_SIZE];

int request_ticket(int sock, const char *server) {
    Message msg;
    msg.type = REQUEST_TICKET;
    strncpy((char *)msg.data, server, sizeof(msg.data));
    msg.length = strlen(server) + 1;
    
    if (send_message(sock, &msg) != SUCCESS) {
        printf("Failed to send ticket request\n");
        return FAILURE;
    }
    
    if (recv_message(sock, &msg) != SUCCESS) {
        printf("Failed to receive ticket\n");
        return FAILURE;
    }
    
    memcpy(session_key, msg.data, KEY_SIZE);
    return SUCCESS;
}

int main() {
    int kdc_sock = connect_to_server(KDC_HOST, KDC_PORT);
    if (kdc_sock < 0) {
        fprintf(stderr, "Failed to connect to KDC\n");
        return 1;
    }
    
    if (request_ticket(kdc_sock, PRN_SERVER) != SUCCESS) {
        fprintf(stderr, "Failed to obtain ticket\n");
        return 1;
    }
    close(kdc_sock);
    
    int prn_sock = connect_to_server(PRN_HOST, PRN_PORT);
    if (prn_sock < 0) {
        fprintf(stderr, "Failed to connect to print server\n");
        return 1;
    }
    
    Message msg;
    msg.type = AUTHENTICATE;
    memcpy(msg.data, session_key, KEY_SIZE);
    msg.length = KEY_SIZE;
    
    if (send_message(prn_sock, &msg) != SUCCESS) {
        fprintf(stderr, "Failed to authenticate\n");
        return 1;
    }
    
    printf("Authenticated successfully. Sending print job...\n");
    
    char *print_data = "Test print job";
    unsigned char encrypted_data[BUFFER_SIZE];
    int encrypted_len = encrypt_gcm((unsigned char *)print_data, strlen(print_data), session_key, encrypted_data);
    
    msg.type = PRINT_JOB;
    memcpy(msg.data, encrypted_data, encrypted_len);
    msg.length = encrypted_len;
    
    if (send_message(prn_sock, &msg) != SUCCESS) {
        fprintf(stderr, "Failed to send print job\n");
        return 1;
    }
    
    printf("Print job sent successfully!\n");
    close(prn_sock);
    return 0;
}