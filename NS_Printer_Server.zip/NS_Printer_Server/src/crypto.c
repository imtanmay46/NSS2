#include "../include/crypto.h"

int derive_key_from_password(const char *password, unsigned char *key, unsigned char *salt) {
    // Generate a random salt if not provided
    if (salt[0] == 0) {
        if (RAND_bytes(salt, 16) != 1) {
            ERR_print_errors_fp(stderr);
            return ERROR_CRYPTO;
        }
    }
    
    // Use PBKDF2 to derive a key from the password
    if (PKCS5_PBKDF2_HMAC(password, strlen(password), salt, 16, 
                          10000, EVP_sha256(), KEY_SIZE, key) != 1) {
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    
    return SUCCESS;
}

int generate_nonce(unsigned char *nonce, size_t size) {
    if (RAND_bytes(nonce, size) != 1) {
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    return SUCCESS;
}

int encrypt_gcm(const unsigned char *plaintext, size_t plaintext_len,
                const unsigned char *key, const unsigned char *iv,
                unsigned char *ciphertext, unsigned char *tag) {
    EVP_CIPHER_CTX *ctx;
    int len, ciphertext_len;
    
    // Create and initialize the context
    if (!(ctx = EVP_CIPHER_CTX_new())) {
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    
    // Initialize the encryption operation
    if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv)) {
        EVP_CIPHER_CTX_free(ctx);
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    
    // Provide the plaintext to be encrypted
    if (1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len)) {
        EVP_CIPHER_CTX_free(ctx);
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    ciphertext_len = len;
    
    // Finalize the encryption
    if (1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len)) {
        EVP_CIPHER_CTX_free(ctx);
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    ciphertext_len += len;
    
    // Get the tag
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, TAG_SIZE, tag)) {
        EVP_CIPHER_CTX_free(ctx);
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    
    // Clean up
    EVP_CIPHER_CTX_free(ctx);
    
    return ciphertext_len;
}

int decrypt_gcm(const unsigned char *ciphertext, size_t ciphertext_len,
                const unsigned char *key, const unsigned char *iv,
                const unsigned char *tag, unsigned char *plaintext) {
    EVP_CIPHER_CTX *ctx;
    int len, plaintext_len, ret;
    
    // Create and initialize the context
    if (!(ctx = EVP_CIPHER_CTX_new())) {
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    
    // Initialize the decryption operation
    if (1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv)) {
        EVP_CIPHER_CTX_free(ctx);
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    
    // Provide the ciphertext to be decrypted
    if (1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len)) {
        EVP_CIPHER_CTX_free(ctx);
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    plaintext_len = len;
    
    // Set the tag
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, TAG_SIZE, (void*)tag)) {
        EVP_CIPHER_CTX_free(ctx);
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
    
    // Finalize the decryption
    ret = EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    
    // Clean up
    EVP_CIPHER_CTX_free(ctx);
    
    if (ret > 0) {
        plaintext_len += len;
        return plaintext_len;
    } else {
        // Authentication failed
        ERR_print_errors_fp(stderr);
        return ERROR_CRYPTO;
    }
}

int create_ticket(const char *client_id, const unsigned char *session_key,
                  const unsigned char *kdc_key, unsigned char *ticket_data) {
    Ticket ticket;
    unsigned char iv[IV_SIZE] = {0};
    unsigned char tag[TAG_SIZE];
    
    // Generate a random IV
    if (generate_nonce(iv, IV_SIZE) != SUCCESS) {
        return ERROR_CRYPTO;
    }
    
    // Fill the ticket structure
    memset(&ticket, 0, sizeof(Ticket));
    strncpy((char*)ticket.client_id, client_id, 31);
    memcpy(ticket.session_key, session_key, KEY_SIZE);
    ticket.expiry = time(NULL) + 3600; // Valid for 1 hour
    
    // Encrypt the ticket using the KDC key
    int ticket_len = encrypt_gcm((unsigned char*)&ticket, sizeof(Ticket),
                               kdc_key, iv, ticket_data + IV_SIZE, tag);
    
    if (ticket_len < 0) {
        return ERROR_CRYPTO;
    }
    
    // Prepend the IV to the ticket data
    memcpy(ticket_data, iv, IV_SIZE);
    // Append the tag to the ticket data
    memcpy(ticket_data + IV_SIZE + ticket_len, tag, TAG_SIZE);
    
    return IV_SIZE + ticket_len + TAG_SIZE;
}

int verify_ticket(const unsigned char *ticket_data, const unsigned char *kdc_key,
                  Ticket *ticket) {
    unsigned char iv[IV_SIZE];
    unsigned char tag[TAG_SIZE];
    unsigned char decrypted[sizeof(Ticket)];
    
    // Extract the IV from the ticket data
    memcpy(iv, ticket_data, IV_SIZE);
    
    // Extract the tag (it's at the end of the ciphertext)
    size_t ciphertext_len = sizeof(Ticket);
    memcpy(tag, ticket_data + IV_SIZE + ciphertext_len, TAG_SIZE);
    
    // Decrypt the ticket
    int result = decrypt_gcm(ticket_data + IV_SIZE, ciphertext_len,
                           kdc_key, iv, tag, decrypted);
    
    if (result < 0) {
        return ERROR_CRYPTO;
    }
    
    // Copy the decrypted ticket
    memcpy(ticket, decrypted, sizeof(Ticket));
    
    // Check if the ticket is expired
    if (ticket->expiry < time(NULL)) {
        return ERROR_AUTH;
    }
    
    return SUCCESS;
}