#include "../include/kdc.h"

// Hardcoded client database for demonstration purposes
// In a real implementation, this would be stored securely
ClientEntry clients[2] = {
    {"alice", {0}, {0}},
    {"bob", {0}, {0}}
};
int num_clients = 2;

// Key shared between KDC and Print Server
unsigned char prnsrv_key[KEY_SIZE] = {0};

void* handle_client(void* arg) {
    ThreadArgs* args = (ThreadArgs*)arg;
    int client_socket = args->client_socket;
    struct sockaddr_in client_addr = args->client_addr;
    free(args);
    
    printf("Client connected: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
    
    // Authenticate client
    int result = authenticate_client(client_socket, clients, num_clients);
    if (result < 0) {
        printf("Authentication failed for client %s:%d\n", 
               inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
        close(client_socket);
        return NULL;
    }
    
    // Issue ticket to the authenticated client
    char username[32];
    strncpy(username, clients[result].username, 31);
    result = issue_ticket(client_socket, username, clients, num_clients, prnsrv_key);
    if (result < 0) {
        printf("Failed to issue ticket for client %s\n", username);
    } else {
        printf("Ticket issued to client %s\n", username);
    }
    
    close(client_socket);
    return NULL;
}

int authenticate_client(int client_socket, ClientEntry* clients, int num_clients) {
    Message msg;
    unsigned char nonce[NONCE_SIZE];
    unsigned char encrypted_nonce[BUFFER_SIZE];
    unsigned char tag[TAG_SIZE];
    unsigned char iv[IV_SIZE];
    char username[32];
    int client_index = -1;
    
    // Receive authentication request
    if (receive_message(client_socket, &msg) != SUCCESS) {
        return ERROR_SOCKET;
    }
    
    if (msg.type != MSG_AUTH_REQUEST) {
        return ERROR_AUTH;
    }
    
    // Extract username
    strncpy(username, (char*)msg.data, 31);
    username[31] = '\0';
    
    // Find client in database
    for (int i = 0; i < num_clients; i++) {
        if (strcmp(username, clients[i].username) == 0) {
            client_index = i;
            break;
        }
    }
    
    if (client_index == -1) {
        return ERROR_AUTH;
    }
    
    // Generate a random nonce for challenge
    if (generate_nonce(nonce, NONCE_SIZE) != SUCCESS) {
        return ERROR_CRYPTO;
    }
    
    // Generate a random IV
    if (generate_nonce(iv, IV_SIZE) != SUCCESS) {
        return ERROR_CRYPTO;
    }
    
    // Send challenge to client
    msg.type = MSG_AUTH_CHALLENGE;
    msg.length = NONCE_SIZE + IV_SIZE;
    memcpy(msg.data, nonce, NONCE_SIZE);
    memcpy(msg.data + NONCE_SIZE, iv, IV_SIZE);
    
    if (send_message(client_socket, &msg) != SUCCESS) {
        return ERROR_SOCKET;
    }
    
    // Receive response
    if (receive_message(client_socket, &msg) != SUCCESS) {
        return ERROR_SOCKET;
    }
    
    if (msg.type != MSG_AUTH_RESPONSE) {
        return ERROR_AUTH;
    }
    
    // Extract encrypted nonce and tag
    memcpy(encrypted_nonce, msg.data, msg.length - TAG_SIZE);
    memcpy(tag, msg.data + msg.length - TAG_SIZE, TAG_SIZE);
    
    // Decrypt and verify the nonce
    unsigned char decrypted_nonce[NONCE_SIZE];
    int result = decrypt_gcm(encrypted_nonce, NONCE_SIZE, clients[client_index].key, 
                            iv, tag, decrypted_nonce);
    
    if (result < 0 || memcmp(nonce, decrypted_nonce, NONCE_SIZE) != 0) {
        return ERROR_AUTH;
    }
    
    // Send authentication success
    msg.type = MSG_AUTH_SUCCESS;
    msg.length = 0;
    
    if (send_message(client_socket, &msg) != SUCCESS) {
        return ERROR_SOCKET;
    }
    
    return client_index;
}

int issue_ticket(int client_socket, const char* username, ClientEntry* clients, 
                int num_clients, const unsigned char* prnsrv_key) {
    Message msg;
    unsigned char session_key[KEY_SIZE];
    unsigned char ticket_data[BUFFER_SIZE];
    unsigned char encrypted_data[BUFFER_SIZE];
    unsigned char tag[TAG_SIZE];
    unsigned char iv[IV_SIZE];
    int client_index = -1;
    
    // Find client in database
    for (int i = 0; i < num_clients; i++) {
        if (strcmp(username, clients[i].username) == 0) {
            client_index = i;
            break;
        }
    }
    
    if (client_index == -1) {
        return ERROR_AUTH;
    }
    
    // Generate a random session key
    if (generate_nonce(session_key, KEY_SIZE) != SUCCESS) {
        return ERROR_CRYPTO;
    }
    
    // Generate a random IV
    if (generate_nonce(iv, IV_SIZE) != SUCCESS) {
        return ERROR_CRYPTO;
    }
    
    // Create a ticket for the print server
    int ticket_len = create_ticket(username, session_key, prnsrv_key, ticket_data);
    if (ticket_len < 0) {
        return ERROR_CRYPTO;
    }
    
    // Prepare the data to encrypt for the client
    // Format: [session_key (32 bytes)][ticket_data (ticket_len bytes)]
    unsigned char plaintext[BUFFER_SIZE];
    memcpy(plaintext, session_key, KEY_SIZE);
    memcpy(plaintext + KEY_SIZE, ticket_data, ticket_len);
    
    // Encrypt the data with the client's key
    int ciphertext_len = encrypt_gcm(plaintext, KEY_SIZE + ticket_len,
                                    clients[client_index].key, iv, encrypted_data, tag);
    
    if (ciphertext_len < 0) {
        return ERROR_CRYPTO;
    }
    
    // Prepare the message
    msg.type = MSG_TICKET;
    msg.length = IV_SIZE + ciphertext_len + TAG_SIZE;
    memcpy(msg.data, iv, IV_SIZE);
    memcpy(msg.data + IV_SIZE, encrypted_data, ciphertext_len);
    memcpy(msg.data + IV_SIZE + ciphertext_len, tag, TAG_SIZE);
    
    // Send the message
    if (send_message(client_socket, &msg) != SUCCESS) {
        return ERROR_SOCKET;
    }
    
    return SUCCESS;
}

int main() {
    int server_fd, client_socket;
    struct sockaddr_in client_addr;
    socklen_t addrlen = sizeof(client_addr);
    pthread_t thread_id;
    
    // Initialize OpenSSL
    OpenSSL_add_all_algorithms();
    
    // Initialize client keys from passwords
    const char* passwords[] = {"alicepassword", "bobpassword"};
    for (int i = 0; i < num_clients; i++) {
        derive_key_from_password(passwords[i], clients[i].key, clients[i].salt);
        printf("Client %s key initialized\n", clients[i].username);
    }
    
    // Initialize the key shared with the print server
    const char* prnsrv_password = "printserverkey";
    unsigned char salt[16] = {0};
    derive_key_from_password(prnsrv_password, prnsrv_key, salt);
    printf("Print server key initialized\n");
    
    // Create socket
    server_fd = create_socket(KDC_PORT);
    if (server_fd < 0) {
        fprintf(stderr, "Failed to create socket\n");
        return 1;
    }
    
    printf("KDC server started on port %d\n", KDC_PORT);
    
    // Accept and handle client connections
    while (1) {
        if ((client_socket = accept(server_fd, (struct sockaddr *)&client_addr, &addrlen)) < 0) {
            perror("Accept failed");
            continue;
        }
        
        // Create thread arguments
        ThreadArgs* args = (ThreadArgs*)malloc(sizeof(ThreadArgs));
        args->client_socket = client_socket;
        args->client_addr = client_addr;
        
        // Create a new thread to handle the client
        if (pthread_create(&thread_id, NULL, handle_client, args) != 0) {
            perror("Thread creation failed");
            free(args);
            close(client_socket);
        } else {
            // Detach the thread
            pthread_detach(thread_id);
        }
    }
    
    close(server_fd);
    return 0;
}