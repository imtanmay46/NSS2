#ifndef PRNSRV_H
#define PRNSRV_H

#include "common.h"
#include "crypto.h"

// Function prototypes
void* handle_client(void* arg);
int process_file_request(int client_socket, const unsigned char* session_key);
int convert_to_pdf(const char* input_path, const char* output_path);

#endif