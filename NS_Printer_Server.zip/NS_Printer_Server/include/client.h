#ifndef CLIENT_H
#define CLIENT_H

#include "common.h"
#include "crypto.h"

// Function prototypes
int authenticate_with_kdc(int kdc_socket, const char* username, const char* password, 
                         unsigned char* session_key, unsigned char* ticket_data, size_t* ticket_len);
int authenticate_with_prnsrv(int prnsrv_socket, const unsigned char* ticket_data, 
                            size_t ticket_len, const unsigned char* session_key);
int send_file_to_prnsrv(int prnsrv_socket, const char* filename, const unsigned char* session_key);
int receive_pdf_from_prnsrv(int prnsrv_socket, const char* output_filename, const unsigned char* session_key);

#endif