#ifndef KDC_H
#define KDC_H

#include "common.h"
#include "crypto.h"

// Client database entry
typedef struct {
    char username[32];
    unsigned char key[KEY_SIZE];
    unsigned char salt[16];
} ClientEntry;

// Function prototypes
void* handle_client(void* arg);
int authenticate_client(int client_socket, ClientEntry* clients, int num_clients);
int issue_ticket(int client_socket, const char* username, ClientEntry* clients, 
                int num_clients, const unsigned char* prnsrv_key);

#endif