#ifndef CRYPTO_H
#define CRYPTO_H

#include "common.h"

// Ticket structure
typedef struct {
    unsigned char client_id[32];
    unsigned char session_key[KEY_SIZE];
    time_t expiry;
} Ticket;

// Function prototypes
int derive_key_from_password(const char *password, unsigned char *key, unsigned char *salt);
int generate_nonce(unsigned char *nonce, size_t size);
int encrypt_gcm(const unsigned char *plaintext, size_t plaintext_len,
                const unsigned char *key, const unsigned char *iv,
                unsigned char *ciphertext, unsigned char *tag);
int decrypt_gcm(const unsigned char *ciphertext, size_t ciphertext_len,
                const unsigned char *key, const unsigned char *iv,
                const unsigned char *tag, unsigned char *plaintext);
int create_ticket(const char *client_id, const unsigned char *session_key,
                  const unsigned char *kdc_key, unsigned char *ticket_data);
int verify_ticket(const unsigned char *ticket_data, const unsigned char *kdc_key,
                  Ticket *ticket);

#endif