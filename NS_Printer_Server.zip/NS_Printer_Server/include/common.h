#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <openssl/ssl.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/err.h>

#define KDC_PORT 8000
#define PRNSRV_PORT 8001
#define MAX_CLIENTS 10
#define BUFFER_SIZE 8192
#define NONCE_SIZE 16
#define KEY_SIZE 32
#define IV_SIZE 12
#define TAG_SIZE 16

// Message types
#define MSG_AUTH_REQUEST 1
#define MSG_AUTH_CHALLENGE 2
#define MSG_AUTH_RESPONSE 3
#define MSG_AUTH_SUCCESS 4
#define MSG_TICKET 5
#define MSG_FILE_REQUEST 6
#define MSG_FILE_RESPONSE 7

// Error codes
#define SUCCESS 0
#define ERROR_SOCKET -1
#define ERROR_CONNECT -2
#define ERROR_BIND -3
#define ERROR_LISTEN -4
#define ERROR_ACCEPT -5
#define ERROR_CRYPTO -6
#define ERROR_AUTH -7
#define ERROR_FILE -8

// Message structure
typedef struct {
    int type;
    size_t length;
    unsigned char data[BUFFER_SIZE];
} Message;

// Thread argument structure
typedef struct {
    int client_socket;
    struct sockaddr_in client_addr;
} ThreadArgs;

// Function prototypes for common functions
int create_socket(int port);
int connect_to_server(const char *server_ip, int port);
int send_message(int socket, Message *msg);
int receive_message(int socket, Message *msg);

#endif