#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdarg.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

#define AES_KEY_SIZE 32
#define AES_IV_SIZE 12
#define AES_TAG_SIZE 16

#define KDC_IP "127.0.0.1"
#define KDC_PORT 8500
#define PRNSRV_IP "127.0.0.2"
#define PRNSRV_PORT 8501

void logs(const char *format, ...)
{
    va_list arguments;
    va_start(arguments, format);
    vprintf(format, arguments);
    printf("\n");
    va_end(arguments);
}

int connection_req(int srv_socket)
{
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);

    int client_socket = accept(srv_socket, (struct sockaddr *)&client_addr, &addr_len);
    if (client_socket == -1)
    {
        perror("Connection request failure...");
        return -1;
    }

    logs("Connected with the client...");
    return client_socket;
}

void send_encrypt_file(int socket, const char *filename, unsigned char *session_key)
{
    (void)session_key;
    FILE *file = fopen(filename, "rb");
    unsigned char buffer[1024];
    size_t bytes_read;

    if (file == NULL)
    {
        perror("ERROR: Unable to open file. Either the filename is wrong or it does not exist...");
        return;
    }

    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0)
    {
        if (send(socket, buffer, bytes_read, 0) < 0)
        {
            perror("ERROR: Couldn't send file...");
            fclose(file);
            return;
        }
    }

    fclose(file);
    logs("File %s was sent successfully.", filename);
}

void receive_encrypt_file(int socket, const char *output_filename, unsigned char *session_key)
{
    (void)session_key;
    FILE *file = fopen(output_filename, "wb");
    unsigned char buffer[1024];
    ssize_t bytes_received;

    if (file == NULL)
    {
        perror("ERROR: Unable to open file. Either the filename is wrong or it does not exist...");
        return;
    }

    while ((bytes_received = recv(socket, buffer, sizeof(buffer), 0)) > 0)
    {
        fwrite(buffer, 1, bytes_received, file);
    }

    fclose(file);
    logs("File %s was received successfully.", output_filename);
}

int create_srv_sock(int port)
{
    int srv_fd;
    struct sockaddr_in addr;
    int opt = 1;

    srv_fd = socket(AF_INET, SOCK_STREAM, 0);

    if (srv_fd == 0)
    {
        perror("ERROR: Socket failure...");
        exit(1);
    }

    if (setsockopt(srv_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)))
    {
        perror("ERROR: Setsockopt failure...");
        exit(1);
    }

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    if (bind(srv_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        perror("ERROR: Bind failure...");
        exit(1);
    }

    if (listen(srv_fd, 5) == -1)
    {
        perror("ERROR: Listening failure on Socket...");
        exit(1);
    }

    logs("Server listening on port number: %d...", port);
    return srv_fd;
}

int create_client_sock(const char *ip, int port)
{
    int client_sock;
    struct sockaddr_in srv_addr;

    client_sock = socket(AF_INET, SOCK_STREAM, 0);

    if (client_sock == -1)
    {
        perror("ERROR: Socket couldn't be created...");
        return -1;
    }

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip, &srv_addr.sin_addr) <= 0)
    {
        perror("ERROR: Address not supported...");
        return -1;
    }

    if (connect(client_sock, (struct sockaddr *)&srv_addr, sizeof(srv_addr)) == -1)
    {
        perror("ERROR: Connection failure...");
        return -1;
    }

    logs("Connected to server %s on port number: %d", ip, port);
    return client_sock;
}

int AES_GCM_Encryption(unsigned char *text, int text_len,
                    unsigned char *key, unsigned char *iv,
                    unsigned char *cipher, unsigned char *tag)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL)
        return -1;

    int len;
    int cipher_len = len;

    if ((EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv) != 1) || 
        (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, AES_TAG_SIZE, tag) != 1))
        return -1;

    if (EVP_EncryptUpdate(ctx, cipher, &len, text, text_len) != 1)
        return -1;

    if (EVP_EncryptFinal_ex(ctx, cipher + len, &len) != 1)
        return -1;
    cipher_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return cipher_len;
}

int AES_GCM_Decryption(unsigned char *cipher, int cipher_len,
                    unsigned char *tag, unsigned char *key,
                    unsigned char *iv, unsigned char *text)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL)
        return -1;

    int len;
    int text_len = len;

    if ((EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv) != 1) || 
        (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, AES_TAG_SIZE, tag) != 1))
        return -1;

    if (EVP_DecryptUpdate(ctx, text, &len, cipher, cipher_len) != 1)
        return -1;

    if (EVP_DecryptFinal_ex(ctx, text + len, &len) <= 0)
        return -1;
    text_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return text_len;
}

void create_random_key(unsigned char *key, int size)
{
    if(RAND_bytes(key, size) == 0)
    {
        perror("ERROR: Couldn't generate random key...");
        exit(1);
    }
}

void Authenticate_KDC(int *session_key, unsigned char *ticket) {
    int sockfd = create_client_sock(KDC_IP, KDC_PORT);

    unsigned char auth_req[AES_IV_SIZE];
    unsigned char encrypted_auth_req[AES_IV_SIZE];
    unsigned char decrypted_auth_req[AES_IV_SIZE];
    unsigned char secret[AES_KEY_SIZE];
    unsigned char tag[AES_TAG_SIZE];

    create_random_key(auth_req, AES_IV_SIZE);
    
    send(sockfd, auth_req, AES_IV_SIZE, 0);
    logs("Authentication Req: Sent request to KDC...");

    recv(sockfd, encrypted_auth_req, AES_IV_SIZE, 0);
    recv(sockfd, tag, AES_TAG_SIZE, 0);
    logs("Authentication Req: Received encrypted response from KDC...");

    create_random_key(secret, AES_KEY_SIZE);

    if(AES_GCM_Decryption(encrypted_auth_req, AES_IV_SIZE, auth_req, secret, decrypted_auth_req, tag) == -1) {
        logs("ERROR: Decryption failure...");
        close(sockfd);
        return;
    }

    if (memcmp(auth_req, decrypted_auth_req, AES_IV_SIZE) != 0) {
        logs("ERROR: Verification failure...");
        close(sockfd);
        return;
    }

    logs("Authentication Req: Authentication Successfull using KDC...");

    unsigned char encryption_key[AES_KEY_SIZE];
    unsigned char key_tag[AES_TAG_SIZE];
    unsigned char ticket_tag[AES_TAG_SIZE];

    recv(sockfd, encryption_key, AES_KEY_SIZE, 0);
    recv(sockfd, key_tag, AES_TAG_SIZE, 0);
    
    if (AES_GCM_Decryption(encryption_key, AES_KEY_SIZE, auth_req, secret, (unsigned char *)session_key, key_tag) == -1) {
        logs("ERROR: Session key decryption failure...");
        close(sockfd);
        return;
    }

    logs("Successfully received and decrypted session key...");

    recv(sockfd, ticket, 256, 0);
    recv(sockfd, ticket_tag, AES_TAG_SIZE, 0);

    logs("Successfully received ticket from KDC...");

    close(sockfd);
}

void PRNSRV_Communication(int *session_key, unsigned char *ticket, char *filename) {
    int sockfd = create_client_sock(PRNSRV_IP, PRNSRV_PORT);

    unsigned char auth_req[AES_IV_SIZE];
    unsigned char encrypted_auth_req[AES_IV_SIZE];
    unsigned char tag[AES_TAG_SIZE];

    send(sockfd, ticket, 256, 0);
    logs("Interaction: Sent ticket to Printer Server...");

    recv(sockfd, auth_req, AES_IV_SIZE, 0);

    if (AES_GCM_Encryption(auth_req, AES_IV_SIZE, (unsigned char *)session_key, auth_req, encrypted_auth_req, tag) == -1) {
        logs("ERROR: Encryption Failure...");
        close(sockfd);
        return;
    }

    send(sockfd, encrypted_auth_req, AES_IV_SIZE, 0);
    send(sockfd, tag, AES_TAG_SIZE, 0);
    logs("Interaction: Successfully sent encrypted response to Printer Server...");

    send_encrypt_file(sockfd, filename, (unsigned char *)session_key);
    logs("Interaction: Successfully sent file to Printer Server...");

    receive_encrypt_file(sockfd, "output.pdf", (unsigned char *)session_key);
    logs("Interaction: Successfully received converted PDF from Printer Server...");

    close(sockfd);
}

int main(int argc, char *argv[]) {
    int session_key[AES_KEY_SIZE];
    unsigned char ticket[256];

    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    Authenticate_KDC(session_key, ticket);
    PRNSRV_Communication(session_key, ticket, argv[1]);

    return 0;
}