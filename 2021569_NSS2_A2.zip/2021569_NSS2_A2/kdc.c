#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdarg.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

#define AES_KEY_SIZE 32
#define AES_IV_SIZE 12
#define AES_TAG_SIZE 16
#define KDC_PORT 8500
#define PRNSRV_SECRET "Secret_Key"

void logs(const char *format, ...)
{
    va_list arguments;
    va_start(arguments, format);
    vprintf(format, arguments);
    printf("\n");
    va_end(arguments);
}

int connection_req(int srv_socket)
{
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);

    int client_sock = accept(srv_socket, (struct sockaddr *)&client_addr, &addr_len);
    if (client_sock == -1)
    {
        perror("Connection request failure...");
        return -1;
    }

    logs("Connected with the client...");
    return client_sock;
}

void send_encrypt_file(int socket, const char *filename, unsigned char *session_key)
{
    (void)session_key;
    FILE *file = fopen(filename, "rb");
    unsigned char buffer[1024];
    size_t bytes_read;

    if (file == NULL)
    {
        perror("ERROR: Unable to open file. Either the filename is wrong or it does not exist...");
        return;
    }

    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0)
    {
        if (send(socket, buffer, bytes_read, 0) < 0)
        {
            perror("ERROR: Couldn't send file...");
            fclose(file);
            return;
        }
    }

    fclose(file);
    logs("File %s was sent successfully.", filename);
}

void receive_encrypt_file(int socket, const char *output_filename, unsigned char *session_key)
{
    (void)session_key;
    FILE *file = fopen(output_filename, "wb");
    unsigned char buffer[1024];
    ssize_t bytes_received;

    if (file == NULL)
    {
        perror("ERROR: Unable to open file. Either the filename is wrong or it does not exist...");
        return;
    }

    while ((bytes_received = recv(socket, buffer, sizeof(buffer), 0)) > 0)
    {
        fwrite(buffer, 1, bytes_received, file);
    }

    fclose(file);
    logs("File %s was received successfully.", output_filename);
}

int create_srv_sock(int port)
{
    int srv_fd;
    struct sockaddr_in addr;
    int opt = 1;

    srv_fd = socket(AF_INET, SOCK_STREAM, 0);

    if (srv_fd == 0)
    {
        perror("ERROR: Socket failure...");
        exit(1);
    }

    if (setsockopt(srv_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)))
    {
        perror("ERROR: Setsockopt failure...");
        exit(1);
    }

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    if (bind(srv_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        perror("ERROR: Bind failure...");
        exit(1);
    }

    if (listen(srv_fd, 5) == -1)
    {
        perror("ERROR: Listening failure on Socket...");
        exit(1);
    }

    logs("Server listening on port number: %d...", port);
    return srv_fd;
}

int create_client_sock(const char *ip, int port)
{
    int client_sock;
    struct sockaddr_in srv_addr;

    client_sock = socket(AF_INET, SOCK_STREAM, 0);

    if (client_sock == -1)
    {
        perror("ERROR: Socket couldn't be created...");
        return -1;
    }

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip, &srv_addr.sin_addr) <= 0)
    {
        perror("ERROR: Address not supported...");
        return -1;
    }

    if (connect(client_sock, (struct sockaddr *)&srv_addr, sizeof(srv_addr)) == -1)
    {
        perror("ERROR: Connection failure...");
        return -1;
    }

    logs("Connected to server %s on port number: %d", ip, port);
    return client_sock;
}

int AES_GCM_Encryption(unsigned char *text, int text_len,
                    unsigned char *key, unsigned char *iv,
                    unsigned char *cipher, unsigned char *tag)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL)
        return -1;

    int len;
    int cipher_len = len;

    if ((EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv) != 1) || 
        (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, AES_TAG_SIZE, tag) != 1))
        return -1;

    if (EVP_EncryptUpdate(ctx, cipher, &len, text, text_len) != 1)
        return -1;

    if (EVP_EncryptFinal_ex(ctx, cipher + len, &len) != 1)
        return -1;
    cipher_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return cipher_len;
}

int AES_GCM_Decryption(unsigned char *cipher, int cipher_len,
                    unsigned char *tag, unsigned char *key,
                    unsigned char *iv, unsigned char *text)
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL)
        return -1;

    int len;
    int text_len = len;

    if ((EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv) != 1) || 
        (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, AES_TAG_SIZE, tag) != 1))
        return -1;

    if (EVP_DecryptUpdate(ctx, text, &len, cipher, cipher_len) != 1)
        return -1;

    if (EVP_DecryptFinal_ex(ctx, text + len, &len) <= 0)
        return -1;
    text_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return text_len;
}

void create_random_key(unsigned char *key, int size)
{
    if(RAND_bytes(key, size) == 0)
    {
        perror("ERROR: Couldn't generate random key...");
        exit(1);
    }
}

void Client_handler(int client_sock) {
    unsigned char secret[AES_KEY_SIZE];
    unsigned char auth_req[AES_IV_SIZE];
    unsigned char encrypted_auth_req[AES_IV_SIZE];
    unsigned char ticket[256];
    unsigned char encrypted_key[256];
    unsigned char session_key[AES_KEY_SIZE];
    unsigned char tag[AES_TAG_SIZE];
    unsigned char key_tag[AES_TAG_SIZE];
    unsigned char ticket_tag[AES_TAG_SIZE];

    create_random_key(secret, AES_KEY_SIZE);

    if (recv(client_sock, auth_req, AES_IV_SIZE, 0) <= 0) {
        logs("AUTH REQ ERROR...");
        close(client_sock);
        return;
    }

    logs("Successfully received authentication response...");

    if (AES_GCM_Encryption(auth_req, AES_IV_SIZE, secret, auth_req, encrypted_auth_req, tag) == -1) {
        logs("Encryption failed.");
        close(client_sock);
        return;
    }

    send(client_sock, encrypted_auth_req, AES_IV_SIZE, 0);
    send(client_sock, tag, AES_TAG_SIZE, 0);
    logs("Successfully sent encrypted authentication response...");

    create_random_key(session_key, AES_KEY_SIZE);
    logs("Session Key Generated Successfully...");

    if (AES_GCM_Encryption(session_key, AES_KEY_SIZE, (unsigned char *)PRNSRV_SECRET, auth_req, ticket, ticket_tag) == -1) {
        logs("ERROR: Ticket Creation Failure...");
        close(client_sock);
        return;
    }

    if (AES_GCM_Encryption(session_key, AES_KEY_SIZE, secret, auth_req, encrypted_key, key_tag) == -1) {
        logs("ERROR: Session Key Encryption Failure...");
        close(client_sock);
        return;
    }

    send(client_sock, encrypted_key, AES_KEY_SIZE, 0);
    send(client_sock, key_tag, AES_TAG_SIZE, 0);
    logs("Successfully sent encrypted session key...");

    send(client_sock, ticket, 256, 0);
    send(client_sock, ticket_tag, AES_TAG_SIZE, 0);
    logs("Successfully sent encrypted ticket...");

    close(client_sock);
}

int main() {
    int srv_fd = create_srv_sock(KDC_PORT);
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);

    do{
        int client_sock = accept(srv_fd, (struct sockaddr *)&client_addr, &addr_len);
        if (client_sock == -1) {
            perror("ERROR: Connection failure...");
            continue;
        }
        pthread_t thread;
        logs("Connected to KDC...");
        
        pthread_create(&thread, NULL, (void *)Client_handler, (void *)(intptr_t)client_sock);
        pthread_detach(thread);
    }while(1);

    close(srv_fd);
    return 0;
}
