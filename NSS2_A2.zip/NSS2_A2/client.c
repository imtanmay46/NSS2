#include "common.h"

#define KDC_IP "127.0.0.1"
#define KDC_PORT 8080
#define PRNSRV_IP "127.0.0.1"
#define PRNSRV_PORT 8080

void authenticate_with_kdc(int *session_key, unsigned char *ticket) {
    int sockfd = create_client_socket(KDC_IP, KDC_PORT);

    // Generate a random challenge
    unsigned char challenge[AES_IV_SIZE];
    generate_random_key(challenge, AES_IV_SIZE);
    
    // Send the challenge to KDC
    send(sockfd, challenge, AES_IV_SIZE, 0);
    log_message("Sent challenge to KDC.");

    // Receive the encrypted challenge response
    unsigned char encrypted_challenge[AES_IV_SIZE];
    unsigned char tag[AES_TAG_SIZE];
    recv(sockfd, encrypted_challenge, AES_IV_SIZE, 0);
    recv(sockfd, tag, AES_TAG_SIZE, 0);
    log_message("Received encrypted challenge response from KDC.");

    // Decrypt the response
    unsigned char decrypted_challenge[AES_IV_SIZE];
    if (aes_gcm_decrypt(encrypted_challenge, AES_IV_SIZE, challenge, alice_secret, decrypted_challenge, tag) < 0) {
        log_message("Challenge decryption failed.");
        close(sockfd);
        return;
    }

    // Verify the challenge
    if (memcmp(challenge, decrypted_challenge, AES_IV_SIZE) != 0) {
        log_message("Challenge verification failed.");
        close(sockfd);
        return;
    }

    log_message("Authenticated with KDC.");

    // Receive the encrypted session key
    unsigned char encrypted_key[AES_KEY_SIZE];
    unsigned char key_tag[AES_TAG_SIZE];
    recv(sockfd, encrypted_key, AES_KEY_SIZE, 0);
    recv(sockfd, key_tag, AES_TAG_SIZE, 0);
    
    // Decrypt session key
    if (aes_gcm_decrypt(encrypted_key, AES_KEY_SIZE, challenge, alice_secret, (unsigned char *)session_key, key_tag) < 0) {
        log_message("Session key decryption failed.");
        close(sockfd);
        return;
    }

    log_message("Received and decrypted session key.");

    // Receive the ticket
    unsigned char ticket_tag[AES_TAG_SIZE];
    recv(sockfd, ticket, 256, 0);
    recv(sockfd, ticket_tag, AES_TAG_SIZE, 0);

    log_message("Received ticket from KDC.");

    close(sockfd);
}

void communicate_with_prnsrv(int *session_key, unsigned char *ticket, char *filename) {
    int sockfd = create_client_socket(PRNSRV_IP, PRNSRV_PORT);

    // Send the ticket
    send(sockfd, ticket, 256, 0);
    log_message("Sent ticket to PrnSrv.");

    // Receive response (challenge-response protocol)
    unsigned char challenge[AES_IV_SIZE];
    recv(sockfd, challenge, AES_IV_SIZE, 0);
    
    unsigned char encrypted_challenge[AES_IV_SIZE];
    unsigned char tag[AES_TAG_SIZE];

    if (aes_gcm_encrypt(challenge, AES_IV_SIZE, (unsigned char *)session_key, challenge, encrypted_challenge, tag) < 0) {
        log_message("Failed to encrypt challenge response.");
        close(sockfd);
        return;
    }

    send(sockfd, encrypted_challenge, AES_IV_SIZE, 0);
    send(sockfd, tag, AES_TAG_SIZE, 0);
    log_message("Sent encrypted challenge response to PrnSrv.");

    // Send the file to be converted
    send_file(sockfd, filename, (unsigned char *)session_key);
    log_message("Sent file to PrnSrv.");

    // Receive the converted PDF
    receive_file(sockfd, "output.pdf", (unsigned char *)session_key);
    log_message("Received converted PDF from PrnSrv.");

    close(sockfd);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    int session_key[AES_KEY_SIZE];
    unsigned char ticket[256];

    // Authenticate with KDC
    authenticate_with_kdc(session_key, ticket);

    // Communicate with PrnSrv
    communicate_with_prnsrv(session_key, ticket, argv[1]);

    return 0;
}