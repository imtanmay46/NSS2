#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/hmac.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define KDC_PORT 8080
#define PRN_PORT 9090
#define BUFFER_SIZE 4096
#define SECRET_KEY "alice_secret"

void decrypt_with_secret(unsigned char *ciphertext, unsigned char *key, unsigned char *plaintext);
void encrypt_file(const char *filename, unsigned char *KAP, unsigned char *encrypted_file);
void decrypt_file(unsigned char *encrypted_file, unsigned char *KAP, const char *output_filename);

void authenticate_with_kdc(int sock, char *password, unsigned char *KAP) {
    send(sock, password, strlen(password), 0);
    unsigned char encrypted_response[BUFFER_SIZE];
    recv(sock, encrypted_response, sizeof(encrypted_response), 0);
    decrypt_with_secret(encrypted_response, SECRET_KEY, KAP);
}

void send_file_to_prnsrv(int sock, char *filename, unsigned char *KAP) {
    send(sock, filename, strlen(filename), 0);
    unsigned char encrypted_file[BUFFER_SIZE];
    encrypt_file(filename, KAP, encrypted_file);
    send(sock, encrypted_file, sizeof(encrypted_file), 0);
}

void receive_and_decrypt_pdf(int sock, unsigned char *KAP) {
    unsigned char encrypted_pdf[BUFFER_SIZE];
    recv(sock, encrypted_pdf, sizeof(encrypted_pdf), 0);
    decrypt_file(encrypted_pdf, KAP, "output.pdf");
}

int main() {
    int kdc_sock, prnsrv_sock;
    struct sockaddr_in kdc_addr, prnsrv_addr;
    unsigned char KAP[32];
    
    // Connect to KDC
    kdc_sock = socket(AF_INET, SOCK_STREAM, 0);
    kdc_addr.sin_family = AF_INET;
    kdc_addr.sin_port = htons(KDC_PORT);
    kdc_addr.sin_addr.s_addr = INADDR_ANY;
    connect(kdc_sock, (struct sockaddr *)&kdc_addr, sizeof(kdc_addr));
    authenticate_with_kdc(kdc_sock, "alice_password", KAP);
    close(kdc_sock);
    
    // Connect to Print Server
    prnsrv_sock = socket(AF_INET, SOCK_STREAM, 0);
    prnsrv_addr.sin_family = AF_INET;
    prnsrv_addr.sin_port = htons(PRN_PORT);
    prnsrv_addr.sin_addr.s_addr = INADDR_ANY;
    connect(prnsrv_sock, (struct sockaddr *)&prnsrv_addr, sizeof(prnsrv_addr));
    send_file_to_prnsrv(prnsrv_sock, "document.txt", KAP);
    receive_and_decrypt_pdf(prnsrv_sock, KAP);
    close(prnsrv_sock);
    
    printf("Received and decrypted PDF saved as output.pdf\n");
    return 0;
}