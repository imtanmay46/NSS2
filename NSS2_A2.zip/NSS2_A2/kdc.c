#include "common.h"

#define KDC_PORT 8080
#define PRNSRV_SECRET "prnsrv_secret_key"

void handle_client(int client_socket) {
    unsigned char alice_secret[AES_KEY_SIZE];
    generate_random_key(alice_secret, AES_KEY_SIZE);

    unsigned char challenge[AES_IV_SIZE];
    if (recv(client_socket, challenge, AES_IV_SIZE, 0) <= 0) {
        log_message("Error receiving challenge from Alice.");
        close(client_socket);
        return;
    }
    log_message("Received challenge from Alice.");

    unsigned char encrypted_challenge[AES_IV_SIZE];
    unsigned char tag[AES_TAG_SIZE];
    if (aes_gcm_encrypt(challenge, AES_IV_SIZE, alice_secret, challenge, encrypted_challenge, tag) < 0) {
        log_message("Encryption failed.");
        close(client_socket);
        return;
    }

    send(client_socket, encrypted_challenge, AES_IV_SIZE, 0);
    send(client_socket, tag, AES_TAG_SIZE, 0);
    log_message("Sent encrypted challenge to Alice.");

    unsigned char session_key[AES_KEY_SIZE];
    generate_random_key(session_key, AES_KEY_SIZE);
    log_message("Generated session key for Alice and PrnSrv.");

    unsigned char ticket[256];
    unsigned char ticket_tag[AES_TAG_SIZE];
    if (aes_gcm_encrypt(session_key, AES_KEY_SIZE, (unsigned char *)PRNSRV_SECRET, challenge, ticket, ticket_tag) < 0) {
        log_message("Failed to create ticket.");
        close(client_socket);
        return;
    }

    unsigned char encrypted_key[256];
    unsigned char key_tag[AES_TAG_SIZE];
    if (aes_gcm_encrypt(session_key, AES_KEY_SIZE, alice_secret, challenge, encrypted_key, key_tag) < 0) {
        log_message("Encryption of session key failed.");
        close(client_socket);
        return;
    }

    send(client_socket, encrypted_key, AES_KEY_SIZE, 0);
    send(client_socket, key_tag, AES_TAG_SIZE, 0);
    log_message("Sent encrypted session key to Alice.");

    send(client_socket, ticket, 256, 0);
    send(client_socket, ticket_tag, AES_TAG_SIZE, 0);
    log_message("Sent encrypted ticket to Alice.");

    close(client_socket);
}

int main() {
    int server_fd = create_server_socket(KDC_PORT);
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);

    while (1) {
        int client_socket = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }
        log_message("Alice connected to KDC.");

        pthread_t thread;
        pthread_create(&thread, NULL, (void *)handle_client, (void *)(intptr_t)client_socket);
        pthread_detach(thread);
    }

    close(server_fd);
    return 0;
}
