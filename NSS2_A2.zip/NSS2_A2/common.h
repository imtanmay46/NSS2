#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

#define AES_KEY_SIZE 32   // 256-bit key
#define AES_IV_SIZE 12    // 96-bit IV for AES-GCM
#define AES_TAG_SIZE 16   // 128-bit tag
#define PORT 8080

// Logging function
void log_message(const char *format, ...);

// Network utilities
int create_server_socket(int port);
int create_client_socket(const char *ip, int port);

// AES-GCM Encryption/Decryption
int aes_gcm_encrypt(unsigned char *plaintext, int plaintext_len, 
                    unsigned char *key, unsigned char *iv,
                    unsigned char *ciphertext, unsigned char *tag);

int aes_gcm_decrypt(unsigned char *ciphertext, int ciphertext_len,
                    unsigned char *tag, unsigned char *key, 
                    unsigned char *iv, unsigned char *plaintext);

// Generate a random AES key
void generate_random_key(unsigned char *key, int size);

#endif // COMMON_H