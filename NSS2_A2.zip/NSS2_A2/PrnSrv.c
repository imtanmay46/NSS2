#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/hmac.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define PORT 9090
#define BUFFER_SIZE 4096
#define SECRET_KEY "print_server_secret"

void decrypt_ticket(unsigned char *encrypted_ticket, unsigned char *key, unsigned char *KAP);
void convert_to_pdf(const char *input_file, const char *output_file);
void encrypt_and_send(const char *pdf_filename, unsigned char *KAP, unsigned char *encrypted_pdf);

void *handle_print_request(void *client_socket) {
    int sock = *(int *)client_socket;
    free(client_socket);
    
    unsigned char encrypted_ticket[BUFFER_SIZE];
    recv(sock, encrypted_ticket, sizeof(encrypted_ticket), 0);

    unsigned char KAP[32]; 
    decrypt_ticket(encrypted_ticket, SECRET_KEY, KAP);

    char filename[256];
    recv(sock, filename, sizeof(filename), 0);

    char pdf_filename[256];
    sprintf(pdf_filename, "%s.pdf", filename);
    convert_to_pdf(filename, pdf_filename);

    unsigned char encrypted_pdf[BUFFER_SIZE];
    encrypt_and_send(pdf_filename, KAP, encrypted_pdf);

    send(sock, encrypted_pdf, sizeof(encrypted_pdf), 0);
    
    close(sock);
    return NULL;
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    
    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 5);
    
    printf("Print Server is running on port %d...\n", PORT);
    
    while (1) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
        pthread_t thread;
        int *client_sock = malloc(sizeof(int));
        *client_sock = new_socket;
        pthread_create(&thread, NULL, handle_print_request, client_sock);
        pthread_detach(thread);
    }
    
    close(server_fd);
    return 0;
}