#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/hmac.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define PORT 8080
#define BUFFER_SIZE 512
#define SECRET_KEY "alice_secret"

void encrypt_with_secret(unsigned char *plaintext, unsigned char *key, unsigned char *ciphertext);

void *handle_client(void *client_socket) {
    int sock = *(int *)client_socket;
    free(client_socket);
    
    char alice_pass[BUFFER_SIZE]; 
    recv(sock, alice_pass, sizeof(alice_pass), 0);

    if (strcmp(alice_pass, "alice_password") != 0) {
        printf("Authentication failed.\n");
        close(sock);
        return NULL;
    }

    unsigned char KAP[32];
    RAND_bytes(KAP, 32);
    
    unsigned char encrypted_response[BUFFER_SIZE];
    encrypt_with_secret(KAP, SECRET_KEY, encrypted_response);

    send(sock, encrypted_response, sizeof(encrypted_response), 0);
    
    close(sock);
    return NULL;
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    
    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 5);
    
    printf("KDC Server is running on port %d...\n", PORT);
    
    while (1) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
        pthread_t thread;
        int *client_sock = malloc(sizeof(int));
        *client_sock = new_socket;
        pthread_create(&thread, NULL, handle_client, client_sock);
        pthread_detach(thread);
    }
    
    close(server_fd);
    return 0;
}