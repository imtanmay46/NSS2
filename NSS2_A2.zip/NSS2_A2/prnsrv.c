#include "common.h"

#define PORT 8080

void *handle_client(void *arg) {
    int client_sock = *(int *)arg;
    free(arg);

    unsigned char ticket[256];
    recv(client_sock, ticket, 256, 0);
    log_message("Received ticket from client.");

    // Decrypt and verify the session key
    int session_key[AES_KEY_SIZE];
    unsigned char ticket_tag[AES_TAG_SIZE];
    recv(client_sock, ticket_tag, AES_TAG_SIZE, 0);
    if (aes_gcm_decrypt(ticket, 256, NULL, prnsrv_secret, (unsigned char *)session_key, ticket_tag) < 0) {
        log_message("Ticket verification failed.");
        close(client_sock);
        return NULL;
    }
    log_message("Session key verified.");

    // Perform challenge-response authentication
    unsigned char challenge[AES_IV_SIZE];
    generate_random_key(challenge, AES_IV_SIZE);
    send(client_sock, challenge, AES_IV_SIZE, 0);
    log_message("Sent challenge to client.");

    unsigned char encrypted_challenge[AES_IV_SIZE];
    unsigned char tag[AES_TAG_SIZE];
    recv(client_sock, encrypted_challenge, AES_IV_SIZE, 0);
    recv(client_sock, tag, AES_TAG_SIZE, 0);

    unsigned char decrypted_challenge[AES_IV_SIZE];
    if (aes_gcm_decrypt(encrypted_challenge, AES_IV_SIZE, challenge, (unsigned char *)session_key, decrypted_challenge, tag) < 0 ||
        memcmp(challenge, decrypted_challenge, AES_IV_SIZE) != 0) {
        log_message("Challenge verification failed.");
        close(client_sock);
        return NULL;
    }
    log_message("Client authenticated.");

    // Receive file from client
    char input_file[] = "input_received";
    receive_file(client_sock, input_file, (unsigned char *)session_key);
    log_message("Received file for conversion.");

    // Convert file to PDF
    char output_file[] = "output.pdf";
    char command[256];
    snprintf(command, sizeof(command), "img2pdf %s -o %s", input_file, output_file);
    system(command);
    log_message("Converted file to PDF.");

    // Send back the encrypted PDF
    send_file(client_sock, output_file, (unsigned char *)session_key);
    log_message("Sent converted PDF to client.");

    close(client_sock);
    return NULL;
}

int main() {
    int server_sock = create_server_socket(PORT);
    log_message("Print Server is running...");

    while (1) {
        int *client_sock = malloc(sizeof(int));
        *client_sock = accept_connection(server_sock);
        pthread_t thread;
        pthread_create(&thread, NULL, handle_client, client_sock);
        pthread_detach(thread);
    }

    close(server_sock);
    return 0;
}